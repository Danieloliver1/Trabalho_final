from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
import time
import pandas as pd



link = 'E:/Repositorio_Git/zzz-projeto_final/automacao_web/dados/Ceps_completo.csv'
df = pd.read_csv(link)
df = df[df['Latitude'].isnull()]

# Configurar o WebDriver
chrome_driver_path = "E:/Repositorio_Git/zzz-projeto_final/automacao_web/chromedriver-win64/chromedriver.exe"  # Substitua pelo caminho 

chrome_options = Options()
chrome_options.add_argument("--start-maximized")  # Abrir o navegador maximizado
chrome_options.add_argument("--disable-extensions")  # Desabilitar extensões, se necessário
# chrome_options.add_argument("--disable-gpu")  # Desabilitar GPU para aumentar estabilidade

# Usando Service para configurar o caminho do ChromeDriver
service = Service(executable_path=chrome_driver_path)

# Inicializando o WebDriver com a configuração correta
driver = webdriver.Chrome(service=service, options=chrome_options)

# Iterar sobre todos os endereços no DataFrame
for i, endereco in df.iterrows():
    try:
        # Abrir a página de Google Maps
        driver.get(r"https://www.google.com.br/maps")
        time.sleep(3)

        # Encontrar a barra de pesquisa e inserir o endereço
        search_box = driver.find_element("name", "q")  # A barra de pesquisa tem o nome "q"
        search_box.send_keys(endereco['endereco'])  # Inserir o endereço
        time.sleep(1)
        search_box.send_keys(Keys.RETURN)  # Pressionar Enter para realizar a busca

        # Espera o Google Maps carregar
        time.sleep(3)

        # Aqui, em vez de mover o mouse, vamos diretamente pegar as coordenadas via URL
        current_url = driver.current_url  # A URL do Google Maps pode ter as coordenadas ao final

        # Imprimir a URL para verificar se as coordenadas estão na URL
        print(f"URL Atual para {endereco['endereco']}: {current_url}")

        time.sleep(1)
        # Extrair latitude e longitude da URL (se a URL contiver as coordenadas)
        url_parts = current_url.split('@')
        if len(url_parts) > 1:
            coordinates = url_parts[1].split(',')  # Separando latitude e longitude
            latitude = coordinates[0]
            longitude = coordinates[1]

            # Salvar as coordenadas nas colunas do DataFrame
            df.at[i, 'Latitude'] = latitude
            df.at[i, 'Longitude'] = longitude

            # Imprimir para conferir as coordenadas
            print(f"Latitude: {latitude}, Longitude: {longitude}")
        else:
            print(f"Não foi possível extrair as coordenadas para o endereço: {endereco['endereco']}")
    
    except Exception as e:
        print(f"Erro ao processar o endereço {endereco['endereco']}: {e}")

# Fechar o navegador após o processamento
driver.quit()

# Salvar o DataFrame com as coordenadas adicionadas
df.to_csv('E:/Repositorio_Git/zzz-projeto_final/automacao_web/dados/Ceps_meio_completo.csv', index=False)
